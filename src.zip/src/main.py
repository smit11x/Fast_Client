# наговнокодил smit1x


from time import sleep
import pyautogui
import subprocess
import json



pyautogui.PAUSE = 0.3

setting_list = {
    "login": "None",
    "password": "None",
    "frist_start": "True",
    "loader_path": "None"
}

def create_config():
    print("Идет процесс создание setting.json")
    with open('setting.json', 'w') as file:
        json.dump(setting_list, file, indent=4)
    frist_start()

def frist_start():
    with open("setting.json", 'r') as file:
        setting = json.load(file)
    print("Не нашел настройки, давайте все настроем")
    setting["login"] = input("Введите логин: ")
    setting["password"] = input("Введите пароль: ")
    setting["loader_path"] = input("Введите путь к вашему лоудеру: ")
    setting["frist_start"] = "False"
    sleep(1)
    print("Сохранил все данные")
    with open('setting.json', 'w') as file:
        json.dump(setting, file, indent=4)
    main()


def main():
    with open("setting.json", 'r') as file:
        setting = json.load(file)
    process = subprocess.Popen(setting["loader_path"], shell=True)
    sleep(2)
    for char in setting["login"]:
        pyautogui.press(char)
    pyautogui.press("enter")
    for char in setting["password"]:
        pyautogui.press(char)
    pyautogui.press("enter")

try:
    with open("setting.json", 'r') as file:
        setting = json.load(file)
except FileNotFoundError:
    create_config()
else:
    main()




